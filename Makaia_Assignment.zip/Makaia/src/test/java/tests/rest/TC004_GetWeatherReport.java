package tests.rest;

import java.io.File;
import java.util.List;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;

public class TC004_GetWeatherReport extends RESTAssuredBase {

	@BeforeTest
	public void setValues() {

		testCaseName = "Get Weather Report (REST)";
		testDescription = "Get Weather Report for the given cities";
		nodes = "Weather";
		authors = "Hari";
		category = "REST";
		dataFileName = "TC004";
		dataFileType = "Excel";
	}

	@Test(dataProvider="fetchData")
	public void getWeather(String city,String apiKey) {

		// Post the request
		Response response = getWithQueryParam("weather","q",city,"appid",apiKey);

		// Verify the Content type
		verifyContentType(response, "JSON");

		// Verify the response status code
		verifyResponseCode(response, 200);
		
		/*
		 * System.out.println(response.jsonPath().get("wind.speed"));
		 * 
		 * System.out.println(response.jsonPath().get("main.temp_max"));
		 * System.out.println(response.jsonPath().get("sys.sunset"));
		 */
		

	}

}
