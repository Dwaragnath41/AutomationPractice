package tests.rest;

import java.io.File;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;


public class TC007_CreateJiraIssue extends RESTAssuredBase{

	@BeforeTest
	public void setValues() {
		testCaseName = "Create new jira issue";
		testDescription = "Create new jira issue";
		nodes = "Issue";
		authors = "Haribu";
		category = "API";
		dataFileName = "create";
		dataFileType = "JSON";
	}

	@Test(dataProvider = "fetchData")
	public void createIncident(File file) {		
		
		// Post the request
		Response response = postWithBodyAsFileAndUrl(file,"issue");
		
		response.prettyPrint();
				
		//Verify the Content by Specific Key
		verifyPartialContentWithKey(response, "key", "RS");
		
		// Verify the Content type
		verifyContentType(response, "JSON");
		
		// Verify the response status code
		verifyResponseCode(response, 201);	
		
		// Verify the response time
		verifyResponseTime(response, 10000);
		
	}


}





