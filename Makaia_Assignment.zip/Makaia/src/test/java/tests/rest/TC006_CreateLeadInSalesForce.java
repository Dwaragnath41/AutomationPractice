package tests.rest;

import java.io.File;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;


public class TC006_CreateLeadInSalesForce extends RESTAssuredBase{

	@BeforeTest
	public void setValues() {
		testCaseName = "Create a new Lead (REST)";
		testDescription = "Create a new lead and Verify";
		nodes = "Lead";
		authors = "Hari";
		category = "API";
		dataFileName = "TC006";
		dataFileType = "json";
	}

	@Test(dataProvider = "fetchData")
	public void createIncident(File file) {		
		
		// Post the request
		Response response = postWithBodyAsFileAndUrl(file,"/Lead");
		
		response.prettyPrint();
				
		//Verify the Content by Specific Key
		verifyContentWithKey(response, "success", true);
		
		// Verify the Content type
		verifyContentType(response, "JSON");
		
		// Verify the response status code
		verifyResponseCode(response, 201);	
		
		// Verify the response time
		verifyResponseTime(response, 10000);
		
	}


}





