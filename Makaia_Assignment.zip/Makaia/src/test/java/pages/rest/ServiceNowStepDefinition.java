package pages.rest;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.equalTo;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import io.cucumber.java.en.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import lib.rest.PreAndTest;

public class ServiceNowStepDefinition extends PreAndTest{

	private Response response;
	private ValidatableResponse json;
	private RequestSpecification request;

	@Given("enable logs")
	public void setUp() {
		request = given().log().all();
	}

	@When("{string} is added with {string}")
	public void add_short_description(String key, String value) {
		request = request.contentType(ContentType.JSON).body("{\"" + key + "\" : \"" + value + "\"}");
	}
	

	@When("new {string} is created")
	public void a_new_incident_created(String tableName) {
		response = request.when().post(tableName);
		System.out.println("response: " + response.prettyPrint());
	}

	
	@Then("the status code is {int}")
	public void verify_status_code(int statusCode) {
		json = response.then().statusCode(statusCode);
		reportRequest("Status code is matching with the expected value: "+statusCode, "pass");
	}

	@Then("response includes the following")
	public void response_equals(Map<String, String> responseFields) {
		Set<Entry<String, String>> entrySet = responseFields.entrySet();
		for (Map.Entry<String, String> field : responseFields.entrySet()) {
			if (StringUtils.isNumeric(field.getValue())) {
				json.body(field.getKey(), equalTo(Integer.parseInt(field.getValue())));
			} else {
				json.body(field.getKey(), equalTo(field.getValue()));
			}
		}
		reportRequest("verified the response values", "pass");
	}

	
}
