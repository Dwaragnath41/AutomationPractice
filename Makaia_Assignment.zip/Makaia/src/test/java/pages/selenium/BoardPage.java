package pages.selenium;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import com.aventstack.extentreports.ExtentTest;
import lib.selenium.PreAndPost;

public class BoardPage extends PreAndPost{

	public BoardPage(EventFiringWebDriver driver, ExtentTest test) {	
		this.driver = driver;
		this.test = test;	
		//driver.switchTo().defaultContent();
		PageFactory.initElements(driver, this);
	}		

	
	/*
	 * @FindBy(id="search-dialog-input") private WebElement eleSearch;
	 */	
	public BoardPage searchIssue(String issueId) {
		pause(5000);
		WebElement ele = locateElement("xpath", "//input[@data-test-id='search-dialog-input']");
		typeAndEnter(ele, issueId);
		return this;

	}
	
	public BoardPage verifyIssue(String issueId) {
		verifyDisplayed(locateElement("xpath", "//span[text()='"+issueId+"']"));
		return this;
	}
	
	/*
	 * public HomePage searchUsingFilter(String value) {
	 * type(locateElement("filter"),value); return this; }
	 * 
	 * 
	 * @FindBy(linkText="Create New") WebElement eleCreateNew; public
	 * CreateNewIncident clickCreateNew() { click(eleCreateNew); return new
	 * CreateNewIncident(driver, test); }
	 * 
	 * 
	 * @FindBy(linkText="Open") WebElement eleOpen; public ListChangeRequests
	 * clickOpen() { click(eleOpen); return new ListChangeRequests(driver, test); }
	 */
	
}










